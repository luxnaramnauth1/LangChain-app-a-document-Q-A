from pathlib import Path

import pytest
from langchain_core.language_models import FakeListChatModel

from docs_qa.rag import build_chain, build_retriever, load_docs

DOCS = Path(__file__).parent.parent / "docs"


def test_load_docs_missing_folder():
    with pytest.raises(FileNotFoundError):
        load_docs("nope")


def test_retriever_finds_relevant_file():
    hits = build_retriever(load_docs(DOCS), k=1).invoke("partial index soft-deleted")
    assert hits[0].metadata["source"] == "postgres.md"


def test_chain_returns_answer_and_sources():
    llm = FakeListChatModel(responses=["Use partial indexes."])
    chain = build_chain(build_retriever(load_docs(DOCS), k=2), llm)
    out = chain.invoke({"question": "How do I index soft-deleted rows?"})
    assert out["answer"] == "Use partial indexes."
    assert "postgres.md" in out["sources"]


def test_prompt_receives_retrieved_context():
    seen = {}

    class Spy(FakeListChatModel):
        def _generate(self, messages, *a, **kw):
            seen["text"] = messages[-1].content
            return super()._generate(messages, *a, **kw)

    chain = build_chain(build_retriever(load_docs(DOCS), k=1), Spy(responses=["ok"]))
    chain.invoke({"question": "multi-stage builds"})
    assert "multi-stage" in seen["text"] and "[docker.md]" in seen["text"]
