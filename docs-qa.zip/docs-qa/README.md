# Docs Q&A (LangChain)

A small **retrieval-augmented generation (RAG)** app. Point it at a folder of Markdown or text notes,
ask a question, and Claude answers using only those notes, with the source files cited.

Built with **LangChain Expression Language (LCEL)**, **Claude** (via `langchain-anthropic`) and **BM25** keyword retrieval.
No vector database or embeddings API needed.

## How it works

```
question ──▶ BM25 retriever ──▶ top-k chunks ──▶ prompt ──▶ Claude ──▶ answer + sources
              (custom LangChain                   (answer only
               BaseRetriever)                      from context)
```

1. `load_docs` reads every `.md` / `.txt` file in a folder.
2. `RecursiveCharacterTextSplitter` cuts them into overlapping chunks.
3. A custom `BM25Retriever` (subclass of LangChain's `BaseRetriever`) ranks chunks against the question.
4. An LCEL chain formats the chunks into a prompt that tells the model to answer **only** from the context and to say "I don't know" otherwise.
5. The output is `{"answer": ..., "sources": [...]}`.

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
export ANTHROPIC_API_KEY=sk-ant-...
```

## Usage

```bash
# one-shot
python -m docs_qa "How do I index soft-deleted rows?"

# interactive
python -m docs_qa

# your own notes folder, retrieve 5 chunks
python -m docs_qa --docs ~/notes -k 5 "What's our git workflow?"
```

Example:

```
$ python -m docs_qa "How do I index soft-deleted rows?"

Use a partial index on rows where deleted_at IS NULL, and confirm with EXPLAIN ANALYZE.

Sources: postgres.md
```

Change the model with `DOCS_QA_MODEL` (default `claude-sonnet-5-5`).

## Tests

```bash
pytest
```

Tests use LangChain's `FakeListChatModel`, so they run offline with no API key. They verify retrieval ranking,
the chain's output shape, and that retrieved context actually reaches the prompt.

## Project layout

```
src/docs_qa/rag.py   # loader, retriever, prompt, LCEL chain
src/docs_qa/cli.py   # command-line interface
tests/test_rag.py    # offline tests
docs/                # sample notes
```

## Ideas to extend

- Swap BM25 for embeddings + a vector store (Chroma, FAISS) for semantic search
- Add conversation memory for follow-up questions
- Stream tokens to the terminal
- Expose it as a FastAPI endpoint or a Streamlit UI
