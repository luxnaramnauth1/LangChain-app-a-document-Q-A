# Git workflow
Use feature branches and open small pull requests. Rebase before merging to keep history linear.
Write commit messages in the imperative mood, for example "Add login endpoint".
