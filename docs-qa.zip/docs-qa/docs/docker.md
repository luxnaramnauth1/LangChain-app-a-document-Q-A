# Docker tips
Use multi-stage builds to keep images small. Copy only the built artifacts into the final stage.
Pin base image versions instead of using the latest tag so builds are reproducible.
