# Postgres notes
Partial indexes are useful for soft-deleted rows: index only the rows where deleted_at IS NULL.
Run EXPLAIN ANALYZE to confirm a query actually uses the index you created.
