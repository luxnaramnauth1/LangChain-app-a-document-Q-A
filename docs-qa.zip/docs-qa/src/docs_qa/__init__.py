"""Docs Q&A: a small LangChain retrieval-augmented generation app."""
