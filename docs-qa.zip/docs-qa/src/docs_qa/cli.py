"""Command-line interface: ask questions about a folder of notes."""
from __future__ import annotations

import argparse
import os
import sys

from .rag import build_chain, build_retriever, load_docs


def make_llm():
    if not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("Set ANTHROPIC_API_KEY first (https://console.anthropic.com).")
    from langchain_anthropic import ChatAnthropic

    return ChatAnthropic(model=os.environ.get("DOCS_QA_MODEL", "claude-sonnet-5-5"), temperature=0)


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="docs-qa", description="Ask questions about your local notes.")
    p.add_argument("question", nargs="?", help="Question to ask. Omit for interactive mode.")
    p.add_argument("--docs", default="docs", help="Folder of .md/.txt files (default: ./docs)")
    p.add_argument("-k", type=int, default=3, help="Chunks to retrieve (default: 3)")
    args = p.parse_args(argv)

    chain = build_chain(build_retriever(load_docs(args.docs), k=args.k), make_llm())

    def ask(q: str) -> None:
        out = chain.invoke({"question": q})
        print(f"\n{out['answer']}\n\nSources: {', '.join(out['sources'])}\n")

    if args.question:
        ask(args.question)
        return
    print("Interactive mode. Type a question, or 'quit' to exit.")
    while (q := input("> ").strip()).lower() not in {"quit", "exit"}:
        if q:
            ask(q)


if __name__ == "__main__":
    main()
