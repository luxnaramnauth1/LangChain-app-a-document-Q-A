"""Core RAG pipeline built with LangChain Expression Language (LCEL)."""
from __future__ import annotations

import re
from operator import itemgetter
from pathlib import Path

from langchain_core.retrievers import BaseRetriever
from rank_bm25 import BM25Okapi
from langchain_core.documents import Document
from pydantic import PrivateAttr
from langchain_core.language_models import BaseChatModel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable, RunnableLambda, RunnableParallel, RunnablePassthrough
from langchain_text_splitters import RecursiveCharacterTextSplitter

SUPPORTED = {".md", ".txt"}

PROMPT = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You answer questions using ONLY the context provided. "
            "If the context does not contain the answer, say you don't know. "
            "Be concise.",
        ),
        ("human", "Context:\n{context}\n\nQuestion: {question}"),
    ]
)


def load_docs(folder: str | Path) -> list[Document]:
    """Load every .md/.txt file under a folder as a Document."""
    folder = Path(folder)
    if not folder.is_dir():
        raise FileNotFoundError(f"Folder not found: {folder}")
    docs = [
        Document(page_content=p.read_text(encoding="utf-8"), metadata={"source": p.name})
        for p in sorted(folder.rglob("*"))
        if p.suffix.lower() in SUPPORTED
    ]
    if not docs:
        raise ValueError(f"No .md or .txt files found in {folder}")
    return docs


def _tokens(text: str) -> list[str]:
    return re.findall(r"\w+", text.lower())


class BM25Retriever(BaseRetriever):
    """Minimal keyword retriever: ranks chunks with BM25 (rank_bm25)."""

    chunks: list[Document]
    k: int = 3
    _index: BM25Okapi = PrivateAttr()

    def model_post_init(self, __context) -> None:
        self._index = BM25Okapi([_tokens(c.page_content) for c in self.chunks])

    def _get_relevant_documents(self, query: str, *, run_manager=None) -> list[Document]:
        scores = self._index.get_scores(_tokens(query))
        ranked = sorted(range(len(self.chunks)), key=scores.__getitem__, reverse=True)
        return [self.chunks[i] for i in ranked[: self.k] if scores[i] > 0]


def build_retriever(docs: list[Document], k: int = 3) -> BM25Retriever:
    """Split documents into chunks and index them with BM25."""
    chunks = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50).split_documents(docs)
    return BM25Retriever(chunks=chunks, k=k)


def format_docs(docs: list[Document]) -> str:
    return "\n\n".join(f"[{d.metadata['source']}]\n{d.page_content}" for d in docs)


def build_chain(retriever, llm: BaseChatModel) -> Runnable:
    """question -> retrieve -> prompt -> LLM -> {answer, sources}."""
    generate = (
        RunnablePassthrough.assign(context=lambda x: format_docs(x["docs"]))
        | PROMPT
        | llm
        | StrOutputParser()
    )
    return (
        RunnableParallel(docs=itemgetter("question") | retriever, question=itemgetter("question"))
        | RunnablePassthrough.assign(answer=generate)
        | RunnableLambda(
            lambda x: {
                "answer": x["answer"],
                "sources": sorted({d.metadata["source"] for d in x["docs"]}),
            }
        )
    )
